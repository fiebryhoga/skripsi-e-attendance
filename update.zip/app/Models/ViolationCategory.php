<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ViolationCategory extends Model
{
    use HasFactory;

    protected $fillable = [
        'grup',
        'kode',
        'deskripsi',
    ];



    public function violations()
    {
        return $this->hasMany(Violation::class);
    }
}